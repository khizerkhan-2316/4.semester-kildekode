﻿using EmployeeDataAccess.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDataAccess.Mappers
{
    internal class EmployeeMapper
    {
        public static DTO.Model.Employee Map(Employee employee)
        {
            return new DTO.Model.Employee(employee.EmployeeId, employee.Name);
        }
        public static Employee Map(DTO.Model.Employee employee)
        {
            return new Employee(employee.EmployeeId, employee.Name);
        }
    }
}
