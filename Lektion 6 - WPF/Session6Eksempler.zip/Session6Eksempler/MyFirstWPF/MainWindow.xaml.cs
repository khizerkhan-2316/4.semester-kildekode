﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyFirstWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Knap.Click += Knap_MinAndenListener;
        }

        private void Knap_MinAndenListener(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            String[] items = { "Skinke", "Pepperoni", "Champignons" };
            SelectedItem.ItemsSource = items;
        }



        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            foreach(String str in NavneListe.SelectedItems)
            {
                MessageBox.Show("Item:" + str);
            }
        }

        private void Knap_Click(object sender, RoutedEventArgs e)
        {
            Valg1.IsChecked = true;
            Knap.Background = new SolidColorBrush(Color.FromRgb(100, 100, 0));
        }

        private void Knap_MouseEnter(object sender, MouseEventArgs e)
        {
            Knap.FontSize = 20;
        }

        private void Knap_MouseMove(object sender, MouseEventArgs e)
        {
            CoordinateLabel.Content = "X:" + e.GetPosition(Knap).X + ",y:" + e.GetPosition(Knap).Y;
            
        }

        private void Knap_MouseLeave(object sender, MouseEventArgs e)
        {
            Knap.FontSize = 12;
        }
    }
}
