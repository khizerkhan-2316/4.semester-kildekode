﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exercise_6_8_radiobuttons_checkboxes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void radioButtonNorth_Checked(object sender, RoutedEventArgs e)
        {
            status_radiobuttons_label.Content = "North checked";
        }

        private void radioButtonSouth_Checked(object sender, RoutedEventArgs e)
        {
            status_radiobuttons_label.Content = "South checked";

        }

        private void radioButtonEast_Checked(object sender, RoutedEventArgs e)
        {
            status_radiobuttons_label.Content = "East checked";

        }

        private void radioButtonWest_Checked(object sender, RoutedEventArgs e)
        {
            status_radiobuttons_label.Content = "West Checked";

        }

        //Below, all the _Checked and _Unchecked methods could just
        //be one method hooked up on all events.
        private void checkBoxLemon_Checked(object sender, RoutedEventArgs e)
        {

            updateCheckBoxLabelUI();
        }

        private void updateCheckBoxLabelUI()
        {
            String status = "";
            if (checkBoxLemon.IsChecked == true)
                status += "Lemon,";
            if (checkBoxOrange.IsChecked == true)
                status += " Orange,";
            if (checkBoxBanana.IsChecked == true)
                status += " Banana,";
            if (status.Contains(","))
                status = status.Remove(status.Length - 1); //remove last ,
            status_checkboxes_label.Content = status; //update label

        }

        private void checkBoxOrange_Checked(object sender, RoutedEventArgs e)
        {
            updateCheckBoxLabelUI();
        }

        private void checkBoxBanana_Checked(object sender, RoutedEventArgs e)
        {
            updateCheckBoxLabelUI();
        }

        private void checkBoxLemon_Unchecked(object sender, RoutedEventArgs e)
        {
            updateCheckBoxLabelUI();
        }

        private void checkBoxOrange_Unchecked(object sender, RoutedEventArgs e)
        {
            updateCheckBoxLabelUI();

        }

        private void checkBoxBanana_Unchecked(object sender, RoutedEventArgs e)
        {
            updateCheckBoxLabelUI();
        }
    }
}
