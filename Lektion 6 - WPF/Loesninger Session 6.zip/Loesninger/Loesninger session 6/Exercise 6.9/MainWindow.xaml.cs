﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exercise_6_9 {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();

            statusBarText.Text = "Some text";
        }


        private void Add1_Click(object sender, RoutedEventArgs e)
        {
            Liste1.Items.Add(Tekst1.Text);
        }

        private void Add2_Click(object sender, RoutedEventArgs e)
        {
            Liste2.Items.Add(Tekst2.Text);
        }

        private void Right_Click(object sender, RoutedEventArgs e)
        {
            MoveItems(Liste1, Liste2);
        }
        private void Left_Click(object sender, RoutedEventArgs e)
        {
            MoveItems(Liste2, Liste1);
        }

        private void MoveItems(ListBox fra, ListBox til)
        {
            foreach(String s in fra.SelectedItems)
            {
                til.Items.Add(s);
            }

            //Nedenstående virker ikke hvis flere items er ens i Liste1.
            //Det er generelt svært at løse og det er bedre at bruge data binding
            List<int> selectedIndices = new List<int>();
            foreach(String s in fra.SelectedItems)
            {
                selectedIndices.Add(fra.Items.IndexOf(s));
            }
            for (int i = selectedIndices.Count-1; i>=0; i--)
            {
                fra.Items.RemoveAt(selectedIndices[i]);
            }
        }

        private void Clear2_Click(object sender, RoutedEventArgs e)
        {
            Liste2.Items.Clear();
        }

        private void Clear1_Click(object sender, RoutedEventArgs e)
        {
            Liste1.Items.Clear();
        }
    }
}
