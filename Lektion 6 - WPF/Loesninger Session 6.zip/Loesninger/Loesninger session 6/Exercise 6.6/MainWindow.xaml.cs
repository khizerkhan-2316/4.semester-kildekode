﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exercise_6_6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_nord_Click(object sender, RoutedEventArgs e)
        {
            textbox.AppendText("North\n");
        }

        private void button_west_Click(object sender, RoutedEventArgs e)
        {
            textbox.AppendText("West\n");
        }

        private void button_east_Click(object sender, RoutedEventArgs e)
        {
            textbox.AppendText("East\n");
        }

        private void button_south_Click(object sender, RoutedEventArgs e)
        {
            textbox.AppendText("South\n");
        }
    }
}
