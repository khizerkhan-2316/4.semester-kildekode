﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exercise_6_7_statusbar_menubar
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void open_menu_Clicked(object sender, RoutedEventArgs e)
        {
            status_label.Content = "Open clicked";

        }

        private void save_as_menu_Clicked(object sender, RoutedEventArgs e)
        {
            status_label.Content = "Save as clicked";

        }

        private void exit_menu_Click(object sender, RoutedEventArgs e)
        {
            status_label.Content = "Exit clicked";

        }

        private void about_menu_Click(object sender, RoutedEventArgs e)
        {
            status_label.Content = "About clicked";
        }
    }
}
