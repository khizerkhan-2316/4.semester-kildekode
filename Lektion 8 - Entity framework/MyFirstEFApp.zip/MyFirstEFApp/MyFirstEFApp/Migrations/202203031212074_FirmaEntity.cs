﻿namespace MyFirstEFApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FirmaEntity : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.Bils", newName: "Bil");
            CreateTable(
                "dbo.Firma",
                c => new
                    {
                        FirmaId = c.Int(nullable: false, identity: true),
                        Navn = c.String(),
                        Adresse = c.String(),
                    })
                .PrimaryKey(t => t.FirmaId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Firma");
            RenameTable(name: "dbo.Bil", newName: "Bils");
        }
    }
}
