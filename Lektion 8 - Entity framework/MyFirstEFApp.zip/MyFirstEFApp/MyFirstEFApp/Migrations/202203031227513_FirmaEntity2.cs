﻿namespace MyFirstEFApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FirmaEntity2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Bil", "Firma_FirmaId", c => c.Int());
            CreateIndex("dbo.Bil", "Firma_FirmaId");
            AddForeignKey("dbo.Bil", "Firma_FirmaId", "dbo.Firma", "FirmaId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Bil", "Firma_FirmaId", "dbo.Firma");
            DropIndex("dbo.Bil", new[] { "Firma_FirmaId" });
            DropColumn("dbo.Bil", "Firma_FirmaId");
        }
    }
}
