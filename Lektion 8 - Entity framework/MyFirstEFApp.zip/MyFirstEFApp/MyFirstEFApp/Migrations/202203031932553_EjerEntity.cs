﻿namespace MyFirstEFApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EjerEntity : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Bil", name: "xyz_FirmaId", newName: "Firma_FirmaId");
            RenameIndex(table: "dbo.Bil", name: "IX_xyz_FirmaId", newName: "IX_Firma_FirmaId");
            CreateTable(
                "dbo.Ejer",
                c => new
                    {
                        EjerId = c.Int(nullable: false, identity: true),
                        EjerNavn = c.String(),
                    })
                .PrimaryKey(t => t.EjerId);
            
            CreateTable(
                "dbo.EjerFirma",
                c => new
                    {
                        Ejer_EjerId = c.Int(nullable: false),
                        Firma_FirmaId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Ejer_EjerId, t.Firma_FirmaId })
                .ForeignKey("dbo.Ejer", t => t.Ejer_EjerId, cascadeDelete: true)
                .ForeignKey("dbo.Firma", t => t.Firma_FirmaId, cascadeDelete: true)
                .Index(t => t.Ejer_EjerId)
                .Index(t => t.Firma_FirmaId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.EjerFirma", "Firma_FirmaId", "dbo.Firma");
            DropForeignKey("dbo.EjerFirma", "Ejer_EjerId", "dbo.Ejer");
            DropIndex("dbo.EjerFirma", new[] { "Firma_FirmaId" });
            DropIndex("dbo.EjerFirma", new[] { "Ejer_EjerId" });
            DropTable("dbo.EjerFirma");
            DropTable("dbo.Ejer");
            RenameIndex(table: "dbo.Bil", name: "IX_Firma_FirmaId", newName: "IX_xyz_FirmaId");
            RenameColumn(table: "dbo.Bil", name: "Firma_FirmaId", newName: "xyz_FirmaId");
        }
    }
}
