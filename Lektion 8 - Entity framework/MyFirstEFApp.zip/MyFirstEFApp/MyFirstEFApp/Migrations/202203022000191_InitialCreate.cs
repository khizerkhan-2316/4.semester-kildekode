﻿namespace MyFirstEFApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Bils",
                c => new
                    {
                        BilID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Weight = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.BilID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Bils");
        }
    }
}
