﻿namespace MyFirstEFApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FirmaEntity3 : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Bil", name: "Firma_FirmaId", newName: "xyz_FirmaId");
            RenameIndex(table: "dbo.Bil", name: "IX_Firma_FirmaId", newName: "IX_xyz_FirmaId");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Bil", name: "IX_xyz_FirmaId", newName: "IX_Firma_FirmaId");
            RenameColumn(table: "dbo.Bil", name: "xyz_FirmaId", newName: "Firma_FirmaId");
        }
    }
}
