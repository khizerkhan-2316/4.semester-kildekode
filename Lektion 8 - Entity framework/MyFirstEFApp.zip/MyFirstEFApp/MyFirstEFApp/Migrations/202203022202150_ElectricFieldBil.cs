﻿namespace MyFirstEFApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ElectricFieldBil : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Bils", "Electric", c => c.Boolean(nullable: false));

        }
        
        public override void Down()
        {
            DropColumn("dbo.Bils", "Electric");
        }
    }
}
