﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Database : DbContext
    {
        public Database() : base("Biler")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
        public DbSet<Bil> Biler { get; set; }
        public DbSet<Firma> Firmaer { get; set; }
        public DbSet<Ejer> Ejer { get; set; }
    }
}
