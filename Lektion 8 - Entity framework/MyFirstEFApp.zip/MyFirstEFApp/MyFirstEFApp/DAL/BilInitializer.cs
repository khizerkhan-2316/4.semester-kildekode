﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    internal class BilInitializer : CreateDatabaseIfNotExists<Database>  //eller CreateDatabaseIfNotExists f.eks.
    {
        protected override void Seed(Database context)
        {

            context.Biler.Add(new Bil("Ford", 1400));
            context.SaveChanges();
        }
    }
}
