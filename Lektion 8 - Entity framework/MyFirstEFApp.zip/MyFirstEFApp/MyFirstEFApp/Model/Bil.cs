﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Bil
    {
        public int BilID { get; set; }
        public string Name { get; set; }
        public int Weight { get; set; }
        public bool Electric { get; set; }
        public Firma Firma { get; set; }
        public Bil()
        {
        }
        public Bil(string name, int weight)
        {
            Name = name;
            Weight = weight;
        }

        public override string ToString()
        {
            return Name + " " + Weight;
        }
    }

}
