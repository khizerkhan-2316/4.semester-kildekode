﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyFirstEFApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Database context = new Database();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void VisBtn_Click(object sender, RoutedEventArgs e)
        {
            BilerListe.Items.Clear();
            foreach(Bil bil in context.Biler)
            {
                BilerListe.Items.Add(bil);
            }
        }

        private void TilfoejBtn_Click(object sender, RoutedEventArgs e)
        {
            Bil b = new Bil("Kia", 750);
            context.Biler.Add(b);
            context.SaveChanges();
        }

        private void RedigerBtn_Click(object sender, RoutedEventArgs e)
        {
            Bil b = (Bil)BilerListe.SelectedItem;
            b.Name = "Tesla";
            context.SaveChanges();
        }

        private void SoegBtn_Click(object sender, RoutedEventArgs e)
        {
            IQueryable<Bil> fundet = context.Biler.Where(x => x.Name == NameSearch.Text);
            BilerListe.Items.Clear();
            foreach(var bil in fundet)
            {
                BilerListe.Items.Add(bil);
            }
        }

        private void OpretFirma_Click(object sender, RoutedEventArgs e)
        {
            Firma firma = new Firma();
            firma.Adresse = "Gaden 2";
            firma.Navn = "JB";
            firma.Biler.Add(new Bil("Ford", 555));
            firma.Biler.Add(new Bil("Chevrolet", 555));
            context.Firmaer.Add(firma);
            
            context.SaveChanges();
        }

        private void Vis_firmaer_Click(object sender, RoutedEventArgs e)
        {
            FirmaListe.Items.Clear();
            foreach(Firma f in context.Firmaer)
            {
                FirmaListe.Items.Add(f);
            }
        }

        private void FirmaListe_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            BilerListe.Items.Clear();
            foreach(Bil b in ((Firma)FirmaListe.SelectedItem).Biler)
            {
                BilerListe.Items.Add(b);
            }
            EjerListe.Items.Clear();
            foreach(Ejer ejer in ((Firma)FirmaListe.SelectedItem).Ejere)
            {
                EjerListe.Items.Add(ejer);
            }
        }

        private void OpretEjer_Click(object sender, RoutedEventArgs e)
        {
            Ejer ejer = new Ejer("Jesper Buch");
            ((Firma)FirmaListe.SelectedItem).Ejere.Add(ejer);
            context.SaveChanges();
        }

        private void VisFirmaerPlusBiler_Click(object sender, RoutedEventArgs e)
        {
            List<Firma> f = new List<Firma>();
            foreach(Firma firma in context.Firmaer)
            {
                f.Add(firma);
            }
            foreach (Firma firma in f)
            {
                MessageBox.Show(firma.Navn);
                foreach (Bil bil in firma.Biler)
                {
                    MessageBox.Show(bil.Name);
                    MessageBox.Show(bil.Firma.Navn);
                }
            }
        }

        private void VisEjersFirmaer_Click(object sender, RoutedEventArgs e)
        {
            foreach(Firma firma in ((Ejer)EjerListe.SelectedItem).Firmaer)
            {
                MessageBox.Show(firma.Navn);
            }
        }
    }
}
