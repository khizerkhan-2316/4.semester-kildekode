﻿using System.Collections.Generic;

namespace Session2Eksempel
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var p = new Person();
        }
        private static int samletAlderForeach(List<Person> list)
        {
            int resultat = 0;
            foreach (Person p in list)
            {
                resultat += p.MinAlder.Aar;
            }
            return resultat;
        }
        private static int samletAlderFor(List<Person> list)
        {
            int resultat = 0;
            for (int i = 0; i < list.Count; i++)
            {
                resultat += list[i].MinAlder.Aar;
            }
            return resultat;
        }
    }
}
