﻿using BLL.Employees;
using DTO.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebAPI.Controllers
{
    public class EmployeeApiController : ApiController
    {
        [HttpGet]
        public Employee GetEmployee(int id)
        {
            EmployeeBLL bll = new EmployeeBLL();
            return bll.getEmployee(id);
        }
        [HttpPost]
        public void AddEmployee(Employee emp)
        {
            EmployeeBLL bll = new EmployeeBLL();
            bll.AddEmployee(emp);
        }
    }
}
