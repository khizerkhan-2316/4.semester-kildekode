﻿using BLL.Employees;
using DTO.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebGUI.Controllers
{
    public class EmployeeController : Controller
    {

        public ActionResult GetEmployee(int? id)
        {
            EmployeeBLL employeeBLL = new EmployeeBLL();
            if (id == null)
            {
                return View("Employee", null);
            }
            else
            {
                return View("Employee", employeeBLL.getEmployee(id.Value));
            }
        }
        [HttpPost]
        public ActionResult AddEmployee(Employee employee)
        {
            if (employee == null)
            {
                return View("Employee", null);
            }
            EmployeeBLL employeeBLL = new EmployeeBLL();
            employeeBLL.AddEmployee(employee);
            return View("AddConfirmation");
        }
        [HttpPost]
        public ActionResult EditEmployee(Employee employee)
        {
            EmployeeBLL employeeBLL = new EmployeeBLL();
            employeeBLL.EditEmployee(employee);
            return View("AddConfirmation");
        }
    }
}