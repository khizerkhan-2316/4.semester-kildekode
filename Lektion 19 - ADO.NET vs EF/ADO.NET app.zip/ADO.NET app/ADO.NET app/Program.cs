﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.NET_app
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String connectionstring = @"Data Source=EAA-SH-KLBO-KU\SQLEXPRESS;Initial Catalog=Employees;Integrated Security=SSPI;";

            ///Eller brug SqlConnectionStringBuilder
            //SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            //builder.DataSource = "<your_server.database.windows.net>";
            //builder.UserID = "<your_username>";
            //builder.Password = "<your_password>";
            //builder.InitialCatalog = "<your_database>";


            //Data reader
            //using (SqlConnection conn = new SqlConnection(connectionstring))
            //{
            //    conn.Open();
            //    String sql = "SELECT EmployeeId, name, age FROM employee";

            //    using (SqlCommand command = new SqlCommand(sql, conn))
            //    {
            //        using (SqlDataReader reader = command.ExecuteReader())
            //        {
            //            while (reader.Read())
            //            {
            //                Console.WriteLine(reader.GetInt32(0));
            //                Console.WriteLine(reader.GetString(1));
            //                Console.WriteLine(reader.GetInt32(2));
            //            }
            //        }
            //    }
            //}


            //Dataset
            //using (SqlConnection conn = new SqlConnection(connectionstring))
            //{
            //    conn.Open();
            //    String sql = "SELECT EmployeeId as Id, Age , name FROM employee";

            //    using (SqlCommand command = new SqlCommand(sql, conn))
            //    {
            //        DataSet ds = new DataSet();
            //        SqlDataAdapter adapter = new SqlDataAdapter(command);
            //        adapter.Fill(ds);
            //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            //        {
            //            Console.WriteLine(ds.Tables[0].Rows[i]["Id"]);
            //            Console.WriteLine(ds.Tables[0].Rows[i][2]);
            //            Console.WriteLine(ds.Tables[0].Rows[i]["age"]);
            //        }
            //    }
            //}


            //Insert into sætning
            //using (SqlConnection conn = new SqlConnection(connectionstring))
            //{
            //    conn.Open();
            //    String name = "Petersen";
            //    String sql = "INSERT INTO employee Values ('" + name + "') ";

            //    using (SqlCommand command = new SqlCommand(sql, conn))
            //    //using (SqlCommand command = conn.CreateCommand())
            //    {
            //        //command.CommandText = sql;
            //        int affected = command.ExecuteNonQuery();
            //        if (affected == 0)
            //        {
            //            //something wrong
            //        }
            //    }
            //}

            //Insert into sætning
            //Med parameters,
            //Transaction
            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();
                try
                {
                    String name = "Ibsen";
                    String sql = "INSERT INTO employee Values (@parName, @parAge) ";

                    //using (SqlCommand command = new SqlCommand(sql, conn))
                    using (SqlCommand command = conn.CreateCommand())
                    {
                        command.CommandText = sql;
                        command.Transaction = transaction;
                        SqlParameter nameParameter = command.CreateParameter();
                        nameParameter.ParameterName = "parName";
                        nameParameter.DbType = DbType.String;
                        nameParameter.Value = name;
                        command.Parameters.Add(nameParameter);
                        SqlParameter ageParameter = command.CreateParameter();
                        ageParameter.ParameterName = "parAge";
                        ageParameter.DbType = DbType.Int32;
                        ageParameter.Value = 24;
                        command.Parameters.Add(ageParameter);
                        int affected = command.ExecuteNonQuery();
                        if (affected == 0)
                        {
                            //something wrong
                            throw new Exception();
                        }
                    }
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                }
            }
        }
    }
}
