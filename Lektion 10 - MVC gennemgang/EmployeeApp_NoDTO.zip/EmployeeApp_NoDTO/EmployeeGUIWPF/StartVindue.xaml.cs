﻿using BLL.Employees;
using EmployeeDataAccess.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeGUIWPF
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        EmployeeBLL bll = new EmployeeBLL();
        Employee emp;
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            emp = bll.getEmployee(Int32.Parse(SearchId.Text));
            Navn.Content = emp.Name;
            YearsEmployed.Content = emp.YearsEmployeed;
            NameToChangeOrAdd.Text = emp.Name;
            Years.Text = emp.YearsEmployeed.ToString();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee(7, NameToChangeOrAdd.Text, int.Parse(Years.Text));
            bll.AddEmployee(emp);
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            emp.YearsEmployeed = int.Parse(Years.Text);
            emp.Name = NameToChangeOrAdd.Text;
            bll.EditEmployee(emp);
        }

        private void FIndCompany_Click(object sender, RoutedEventArgs e)
        {
            Company company = bll.getCompany(1);
            MessageBox.Show(company.CompanyName);
            for (int i = 0; i < company.Employees.Count; i++)
            {
                MessageBox.Show(company.Employees[i].Name);
            }
        }
    }
}
