﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    public class Person
    {
        private String name;

        public Person(String name)
        {
            this.name = name;
        }
        public String Name { 
            get { 
                return name; 
            } 
            set { 
                name = value; 
            }
        }
    }
}
