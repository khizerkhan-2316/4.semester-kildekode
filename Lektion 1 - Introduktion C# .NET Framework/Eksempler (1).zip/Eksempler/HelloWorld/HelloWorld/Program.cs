﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biler;

namespace HelloWorld
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //Console.WriteLine("Hello World");
            //Console.ReadLine();
            //Person p = new Person("Ole");
            //Console.WriteLine(p.Name);
            //Console.ReadLine();
            //p.Name = "Ib";
            //Console.WriteLine(p.Name);
            //Console.ReadLine();

            Bil minbil;
            minbil=new Bil();
            minbil.Maerke = "Ford";
            minbil.AntalHjul = 4;
            Console.WriteLine(minbil.Maerke);
            Console.ReadLine();

        }
    }
}
