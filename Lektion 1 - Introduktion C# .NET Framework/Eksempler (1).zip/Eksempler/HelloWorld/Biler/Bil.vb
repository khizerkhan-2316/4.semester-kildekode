﻿Public Class Bil
    Private _maerke As String
    Private _antalHjul As Integer
    Public Property Maerke() As String
        Get
            Return _maerke
        End Get
        Set(value As String)
            _maerke = value
        End Set
    End Property
    Public Property AntalHjul() As Integer
        Get
            Return _antalHjul
        End Get
        Set(value As Integer)
            _antalHjul = value
        End Set
    End Property

End Class
